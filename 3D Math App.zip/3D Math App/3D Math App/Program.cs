﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3D_Math_App
{
    class Program
    {
        public static void Main(string[] args)
        {
            //this app will let you add, subtract, multiply and divide

            //writes the type of equations the user can select

            Console.WriteLine("What type of mathematical equation would you like to perform?");
            Console.WriteLine("add, sub, mul, div");
            Operations (Convert.ToString(Console.ReadLine()));
            
        }
        //redirects the input of user to methods
        static void Operations(string ops)
        {
            if (ops.ToLower() == "add")
            {
                Console.WriteLine("enter first value");
                int num1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("second value");
                int num2 = Convert.ToInt32(Console.ReadLine());
                //calling the add method
                ADD(num1,num2);
            }

            else if (ops.ToLower() == "sub")
            {
                Console.WriteLine("enter first value");
                int num1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter second value");
                int num2 = Convert.ToInt32(Console.ReadLine());
                //calling the subtract method
                SUB(num1,num2);
            }

            else if (ops.ToLower() == "mul")
            {
                Console.WriteLine("enter first value");
                int num1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter second value");
                int num2 = Convert.ToInt32(Console.ReadLine());
                //calling the multiplication method
                MUL(num1, num2);
            }

            else if (ops.ToLower() == "div")
            {
                Console.WriteLine("enter first value");
                int num1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter second value");
                int num2= Convert.ToInt32(Console.ReadLine());
                DIV(num1, num2);
            }
 
            else
            {
                // it'll write this output when the user writes something other than an operator 
                Console.WriteLine("\tThanks for stopping by!");
            }
            
        }

        public static void ADD(int num1,int num2)
        {
            int add;
            //operators
            add = num1 + num2;

            Console.WriteLine("\nYour Result is {0}", add);
            Console.ReadLine();
        }

        public static void SUB(int num1, int num2)
        {
            int sub;

            //operators
            sub = num1 - num2;

            Console.WriteLine("\nYour Result is {0}", sub);
            Console.ReadLine();
        }

        public static void MUL(int num1, int num2)
        {
            int mul;
            //operators
            mul = num1 * num2;

            Console.WriteLine("\nYour Result is {0}", mul);
            Console.ReadLine();
        }

        public static void DIV(int num1, int num2)
        {
            int div;

            if (num2<=0)
            {
                Console.WriteLine("Re-enter second value");
                DIV(num1, Convert.ToInt32(Console.ReadLine()));
            }
            
            //operators
            div = num1 / num2;
            
            Console.WriteLine("\nYour Result is {0}", div);
            Console.ReadLine();
        }
}

}
