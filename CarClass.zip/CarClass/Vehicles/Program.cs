﻿using CarClass;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car(2011,"STI");
            Console.WriteLine( car.speed );

            for (int i = 0; i < 5; i++) 
            {
                car.Accelarate();
                Console.WriteLine(car.speed);
            }

            for (int i= 0; i < 5; i++)
            {
                car.Brake();
                Console.WriteLine(car.speed);
            }
                Console.ReadLine();
        }
    }
}
