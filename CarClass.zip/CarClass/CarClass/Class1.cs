﻿using System;

namespace CarClass
{
    public class Car
    {
        public Car(int yearModel, string make)
        {
            this.speed = 0;
            this.yearModel = yearModel;
            this.make = make;
        }
        public int yearModel { get; set; }
        public string make { get; set; }
        public int speed { get; set; }

        public Car()
        {
            this.speed = 0;
        }

        public void Accelarate()
        {
            speed += 5;
        }
        public void Brake()
        {
            speed -= 5;
        }
        
    }
}
