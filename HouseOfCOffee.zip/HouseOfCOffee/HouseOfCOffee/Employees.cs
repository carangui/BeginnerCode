﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HouseOfCOffee
{
    struct Employees
    {
        public double EMP1()
        {
            double basicpay = 12.50, overtimepay = 18.75;
            Console.WriteLine("Enter number of hours for first employee");
            double hours = Convert.ToDouble(Console.ReadLine());
            double overtimehours = (hours - 40) * overtimepay;

            if (hours <= 40)
                Console.WriteLine(basicpay * hours);

            else if (hours > 40)
                Console.WriteLine((basicpay * hours) + overtimehours);

            Console.ReadLine();

            return basicpay;
        }

        public double EMP2()
        {
            double basicpay = 12.50, overtimepay = 18.75;
            Console.WriteLine("Enter number of hours for second employee");
            double hours = Convert.ToDouble(Console.ReadLine());
            double overtimehours = (hours - 40) * overtimepay;

            if (hours <= 40)
                Console.WriteLine(basicpay * hours);

            else if (hours > 40)
                Console.WriteLine((basicpay * hours) + overtimehours);

            Console.ReadLine();
            return basicpay;
        }

        public double EMP3()
        {
            double basicpay = 12.50, overtimepay = 18.75;
            Console.WriteLine("Enter number of hours for third employee");
            double hours = Convert.ToDouble(Console.ReadLine());
            double overtimehours = (hours - 40) * overtimepay;

            if (hours <= 40)
                Console.WriteLine(basicpay * hours);

            else if (hours > 40)
                Console.WriteLine((basicpay * hours) + overtimehours);

            Console.ReadLine();
            return basicpay;
        }

        public double EMP4()
        {
            double basicpay = 12.50, overtimepay = 18.75;
            Console.WriteLine("Enter number of hours for fourth employee");
            double hours = Convert.ToDouble(Console.ReadLine());
            double overtimehours = (hours - 40) * overtimepay;

            if (hours <= 40)
                Console.WriteLine(basicpay * hours);

            else if (hours > 40)
                Console.WriteLine((basicpay * hours) + overtimehours);

            Console.ReadLine();
            return basicpay;
        }

        public double EMP5()
        {
            double basicpay = 12.50, overtimepay = 18.75;
            Console.WriteLine("Enter number of hours for fifth employee");
            double hours = Convert.ToDouble(Console.ReadLine());
            double overtimehours = (hours - 40) * overtimepay;

            if (hours <= 40)
                Console.WriteLine(basicpay * hours);

            else if (hours > 40)
                Console.WriteLine((basicpay * hours) + overtimehours);

            Console.ReadLine();
            return basicpay;
        }
    }
    
}
