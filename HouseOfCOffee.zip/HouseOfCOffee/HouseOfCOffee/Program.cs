﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HouseOfCOffee
{
    class Program
    {
        static void Main(string[] args)
        {
            Employees employee = new Employees();
            try
            {
                employee.EMP1();
                employee.EMP2();
                employee.EMP3();
                employee.EMP4();
                employee.EMP5();
            }
            catch (FormatException)
            {
                Console.WriteLine("please enter a number");
            }

            List_of_Items listofitems = new List_of_Items();
            {
                listofitems.TotalSales();
            }
              
        }
    }
}
