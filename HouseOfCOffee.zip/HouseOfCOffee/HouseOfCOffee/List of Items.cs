﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HouseOfCOffee
{
    class List_of_Items
    {
        public double TotalSales()
        {
            Console.WriteLine("How many small coffees did you sell?");
            double smallcoffee = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("How many medium cofees did you sell?");
            double mediumcoffee = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("How many large coffees did you sell?");
            double largecoffee = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("How many egg sanwiches did you sell?");
            double eggsandwich = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("How mamny chicken bicuits did you sell?");
            double chikenbiscuit = Convert.ToDouble(Console.ReadLine());

            double total = (smallcoffee * 1) + (mediumcoffee * 3) + (largecoffee * 5) + (eggsandwich * 5.50) + (chikenbiscuit * 7.50);
            return total;
        }

        public void TotalPlusCost(double total)
        {
            Console.WriteLine("How many small coffees did you sell?");
            double smallcoffee = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("How many medium cofees did you sell?");
            double mediumcoffee = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("How many large coffees did you sell?");
            double largecoffee = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("How many egg sanwiches did you sell?");
            double eggsandwich = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("How mamny chicken bicuits did you sell?");
            double chikenbiscuit = Convert.ToDouble(Console.ReadLine());
        }
    }
}
