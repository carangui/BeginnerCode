﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Military_Unit
{
    public class Missions
    {
        public int Enemies { get; set; }

        public Missions()
        {

        }

        public Missions(int enemies)
        {
            Enemies = enemies;
        }

        public void EnemyAttack()
        {
            Console.WriteLine(Enemies+" Enemies are attacking! Get troops out of combat zone!");
        }

        public void Resupply()
        {
            Console.WriteLine("The troops need water and ammo to continue their mission");
        }

        public class Shortrange
        {
            public virtual void Target()
            {
                Console.WriteLine("The mission of the squadron is to provide support to other units with the use of our Aircraft");
            }
        }

        public class Longrange : Shortrange
        {
            public override void Target()
            {
                Console.WriteLine("The mission of personnel is to maitain aircraft so that every mission can be accomplisehd");
            }

        }
    }
}
