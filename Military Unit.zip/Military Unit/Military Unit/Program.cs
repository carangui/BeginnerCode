﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Military_Unit
{
    class Program
    {
        static void Main(string[] args)
        {
            Missions.Shortrange shortrange = new Missions.Shortrange();
            shortrange.Target();
            Missions.Longrange longrange = new Missions.Longrange();
            longrange.Target();

            var squadron = new Squadron();
            var vehicles = new Vehicles();
            var missions = new Missions();
            
            vehicles.Helicopter = "CH53E";
            vehicles.Aircraft();
            squadron.AirSupport();
            squadron.AirAssault();
            squadron.AirCargo();
            vehicles.AirSupport();
            missions.Resupply();
            missions.Enemies = 300;
            missions.EnemyAttack();
        }
    }
}
