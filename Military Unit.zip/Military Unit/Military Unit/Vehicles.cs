﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Military_Unit
{
    public class Vehicles : Squadron
    {
        public string Helicopter { get; set; }

        public Vehicles()
        {

        }

        public Vehicles(string helicopter)
        {
            Helicopter = helicopter;
        }

        public void Aircraft()
        {
            Console.WriteLine("The "+Helicopter+" helicopter is an assault/support/cargo aircraft, it is very capable");
        }

        public override void AirSupport()
        {
            Console.WriteLine("The squadron utilizes the "+Helicopter+" to provide humanitarian relief");
        }
    }
}
