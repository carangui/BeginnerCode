﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Military_Unit
{
    public class Squadron
    {
        public Squadron()
        {

        }

        public virtual void AirSupport()
        {
            Console.WriteLine("Provide insertion of troops");
        }

        public virtual void AirAssault()
        {
            Console.WriteLine("Provide attack capabilities with .50 cal mounted guns");
        }

        public virtual void AirCargo()
        {
            Console.WriteLine("Provide Heavy Lift for vehicles and other aircraft");
        }
        
    }
}
